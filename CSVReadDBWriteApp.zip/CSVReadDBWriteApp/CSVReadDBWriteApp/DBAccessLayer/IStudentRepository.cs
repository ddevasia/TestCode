﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CSVReadDBWriteApp.DBAccessLayer
{
    public interface IStudentRepository
    {
        bool InsertCSVDataRecords(List<Student> students);
    }
}