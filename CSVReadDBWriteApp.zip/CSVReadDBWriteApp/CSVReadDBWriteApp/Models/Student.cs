﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Student
{    
    public int StudentId { get; set; }
    
    public string FirstName { get; set; }

    [Required,MaxLength(15)]
    public string Surname { get; set; }

    [RegularExpression(@"^\d{2}$", ErrorMessage = "Please Enter Correct Age")]
    public int Age { get; set; }
   
    [RegularExpression(@"^M$|^F$", ErrorMessage = "Enter Valid Sex Please.")]
    public string Sex { get; set; }

    [MaxLength(15)]    
    public string Class { get; set; }

    [Required]
    public bool Active { get; set; }
}
