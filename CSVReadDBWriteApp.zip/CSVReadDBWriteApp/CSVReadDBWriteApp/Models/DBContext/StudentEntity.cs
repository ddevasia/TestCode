﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CSVReadDBWriteApp.Models.DBContext
{
    public class StudentEntity
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int StudentId { get; set; }

        [Required, MaxLength(15)]
        public string FirstName { get; set; }

        [Required, MaxLength(15)]
        public string Surname { get; set; }

        [Required]
        public int Age { get; set; }

        [Required, MaxLength(1)]        
        public string Sex { get; set; }

        [MaxLength(15)]
        public string Class { get; set; }

        [Required]
        public bool Active { get; set; }
    }
}
