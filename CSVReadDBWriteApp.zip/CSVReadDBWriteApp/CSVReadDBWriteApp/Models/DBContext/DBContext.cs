using CSVReadDBWriteApp.Models.DBContext;
using System;
    using System.Data.Entity;
    using System.Linq;

//DBContext
public class DBContext : DbContext
{    
    public DBContext()
        : base()
    {
    }
    
    public virtual DbSet<StudentEntity> Students { get; set; }
}
