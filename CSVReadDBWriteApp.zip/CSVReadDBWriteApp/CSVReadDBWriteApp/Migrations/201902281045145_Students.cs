namespace CSVReadDBWriteApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Students : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Students",
                c => new
                    {
                        StudentId = c.Int(nullable: false, identity: true),
                        FirstName = c.String(),
                        Surname = c.String(nullable: false, maxLength: 15),
                        Age = c.Int(nullable: false),
                        Sex = c.String(),
                        Class = c.String(maxLength: 15),
                        Active = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.StudentId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Students");
        }
    }
}
