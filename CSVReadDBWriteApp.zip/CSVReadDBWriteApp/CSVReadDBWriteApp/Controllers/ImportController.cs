﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Web.Mvc;
using CSVReadDBWriteApp.DBAccessLayer;
using Microsoft.VisualBasic;
using System.Text;
using System.Web.Http;

namespace CSVReadDBWriteApp.Controllers
{
    public class ImportController : Controller
    {        
        public bool Import([FromBody]string fileName)

        {
            List<Student> students = new List<Student>();
            List<string[]> _tempList = new List<string[]>();
            Validation_CSV csvValidate = new Validation_CSV();
            string csvData = ""; int CurrentLine = 0;
            FileStream stream = new FileStream(Server.MapPath(fileName), FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using (StreamReader reader = new StreamReader(stream, Encoding.Default, true, 1024))
            {
                string currentLine;
                while ((currentLine = reader.ReadLine()) != null)
                {
                    if (CurrentLine != 0)
                    {
                        csvData = csvValidate.Validate(csvData);
                        string[] temp = currentLine.Split(new char[] { ',' }, StringSplitOptions.None);

                        _tempList.Add(temp);
                    }
                    CurrentLine += 1;
                }

                foreach(string[] s in _tempList)
                {
                    var newStudentData = new Student
                    {
                        StudentId = int.Parse(s[0]),
                        FirstName = s[1],
                        Surname = s[2],
                        Age = int.Parse(s[3]),
                        Sex = s[4],
                        Class = s[5],
                        Active = bool.Parse(s[6])
                    };
                    students.Add(newStudentData);
                }

                StudentRepository repo = new StudentRepository();
                repo.InsertCSVDataRecords(students);
            }
            return true;
        }
    }
}