﻿using CSVReadDBWriteApp.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVReadDBWriteApp.Tests.Controllers
{
    class ImportControllerTest
    {
        [TestMethod]
        [DataSource("Microsoft.VisualStudio.TestTools.Datasource.CSV", @"|DataDirectory|\Data\Data.csv", "Data#csv", DataAccessMethod.Sequential)]
        public void Import()
        {
            // Arrange
            ImportController controller = new ImportController();

            // Act"
            bool result = controller.Import("Data.csv");

            // Assert
            Assert.IsTrue(result, "Sucess");
            Assert.IsFalse(result, "Failed");
            
        }
    }
}
