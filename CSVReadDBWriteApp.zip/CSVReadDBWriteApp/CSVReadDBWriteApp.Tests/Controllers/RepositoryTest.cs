﻿using CSVReadDBWriteApp.DBAccessLayer;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVReadDBWriteApp.Tests.Controllers
{
    [TestClass]
    public class RepositoryTest
    {

        private readonly StudentRepository _repository;

        public RepositoryTest()
        {
            _repository = new StudentRepository();
        }

        [TestMethod]
        public void InsertCSVDataRecords()
        {

            List<Student> students = new List<Student>();
            Student student1 = new Student();
            student1.StudentId = 1;
            student1.FirstName = "Lewis";
            student1.Surname = "John";
            student1.Sex = "M";
            student1.Class = "3";
            student1.Age = 5;
            student1.Active = true;

            Student student2 = new Student();
            student2.StudentId = 1;
            student2.FirstName = "Lewis";
            student2.Surname = "John";
            student2.Sex = "M";
            student2.Class = "3";
            student2.Age = 5;
            student2.Active = true;

            students.Add(student1);
            students.Add(student2);

            var result = _repository.InsertCSVDataRecords(students);

            Assert.IsTrue(result, "Success");
            Assert.IsFalse(result, "Failed");
        }
    }

}

