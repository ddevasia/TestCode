﻿using CandidateScreening.Data;
using CandidateScreening.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CandidateScreening.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
			CandidateScreeningContext context = new CandidateScreeningContext();
            IndexModel model = new IndexModel
            {
                PatientCount = context.Patients.Count()
            };
            return View(model);
        }
    }
}