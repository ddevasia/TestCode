﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CandidateScreening.Models
{
	public class IndexModel
	{
		public int PatientCount { get; set; }
	}
}